package com.equal.experts.shopping;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.List;

/**
 * Holds the list of shopping items and total price.
 * @author chethan.c
 *
 */
public class ShoppingCart {

	private List<ShoppingItem> shoppingItems;

	private float totalPrice = 0.0f;

	public float getTotalPrice() {
		return totalPrice;
	}

	public ActionResult addToCartAndTotal(ShoppingItem itemsToAdd) {
		ShoppingItemValidator validator = new ShoppingItemValidator();
		List<String> validationErros = validator.validateShoppingItem(itemsToAdd);
		if (!validationErros.isEmpty()) {
			return new ActionResult(Constants.VALIDATION_ERROR, validationErros);
		}
		if (shoppingItems == null) {
			shoppingItems = new ArrayList<ShoppingItem>();
		}
		shoppingItems.add(itemsToAdd);
		totalPrice = totalPrice + (itemsToAdd.getProduct().getPrice() * itemsToAdd.getCount());
		totalPrice = new BigDecimal(totalPrice).setScale(2, RoundingMode.HALF_UP).floatValue();
		return new ActionResult(Constants.SUCCESS_STATUS, null);
	}

	public List<ShoppingItem> getShoppingItems() {
		return shoppingItems;
	}

}
