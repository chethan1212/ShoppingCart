version number - 5b8d0fd276b6d288905ed2f63a934e057e8feca2 

Pre-requisite for the project
Java 1.7 or later version.
Maven version 3.6 or higher( most probably will build with previous versions as well)

Project can be either build using 
1.maven commands from command line assuming maven is installed and mvn and java home is set up. 
2.Or executing build.sh for linux or build.bat for windows machines.( both assumings mvn and JAVA_HOME is set up). Build logs are available in maven_build.log under the root folder.

jacoco is used for code coverage.
Post executing the build script the coverate can be accessed by going to shoppingcart/target/jacoco/index.html
